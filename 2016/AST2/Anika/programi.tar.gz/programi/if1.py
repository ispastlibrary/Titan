n = int(input("Broj? "))
if n < 0:
   print("Apsolutna vrednost", n, "je", -n)
else:
   print("Apsolutna vrednost", n, "je", n)
