#!/usr/bin/env python3

import os

os.system('clear') 

for i in range(0,10):
    print(" ")

##Prints Hello, World!
##print("Hello, World!")

input("Hello, World!")

os.system('clear')
