a = 0
while a < 10:
    a = a + 1
    print(a)
