""" Ovde navodimo ukratko osnovne karakteristike programa
    tj. kako radi, sta radi i sta sa njime postizemo
    (naprimer)
"""

print("Ucimo komentarisanje!")

# Ovo je komentar
