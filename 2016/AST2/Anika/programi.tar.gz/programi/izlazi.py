a = 123.4
b23 = 'Trol'
first_name = "Nemanja"
b = 432
c = a + b
print("a + b is",c)
print("first_name is",first_name)
print("Sorted Parts, After Midnight or",b23)

value1 = 10
value2 = 20
Pim = 10

value1 == Pim
value2 == "Pim"
