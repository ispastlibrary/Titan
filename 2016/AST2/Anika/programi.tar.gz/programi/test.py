import time

#use time.time() on Linux

start = time.clock()
for x in range(10000000):
    pass
stop = time.clock()

print(stop - start)

start = time.clock()
for x in xrange(10000000):
    pass
stop = time.clock()

print(stop - start)
